import React from 'react'
import NewComponent from './components/components/NewComponent'
import { ContactForm } from './components/container/ContactForm'

export default function App() {
  
  return (
    <div>
      <ContactForm/>
      {/* <NewComponent/> */}
    </div>
  )
}
