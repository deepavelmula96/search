import { GET_ALL_CONTACTS_DETAILS,DELETE_CONTACT_DATA,SET_SEARCH_KEY_NEW_BRANCH, ADD_EDIT_CONTACT_DATA_REQUEST, ADD_EDIT_CONTACT_DATA_RESPONSE } from "./ActionTypes"

export const getAllContactsDetails=()=>{
    return{
        type:GET_ALL_CONTACTS_DETAILS
    }
}
export const  deleteContactData=(contact)=>{
    console.log('ddd',contact)
    return{
        type:DELETE_CONTACT_DATA,
        payload:contact
    }
}
export const addEditContactDataRequest=(actionType,data)=>{
    console.log('addEditContactDataRequest',{actionType,data})
    return{
        type:ADD_EDIT_CONTACT_DATA_REQUEST,
        payload:{actionType,data}
    }
}
export const setSearchKeyNewBranch = (value) => {
    return {
        type:SET_SEARCH_KEY_NEW_BRANCH,
        payload: value
    }
}
export const addEditContactDataResponse=(actionType,data)=>{
    console.log('addEditContactDataResponse',{actionType,data})
    return{
        type:ADD_EDIT_CONTACT_DATA_RESPONSE,
        payload:{actionType,data}
    }
}