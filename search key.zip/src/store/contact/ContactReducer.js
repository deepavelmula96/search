import { v4 as uuidv4 } from 'uuid';
import { DELETE_CONTACT_DATA, GET_ALL_CONTACTS_DETAILS,SET_SEARCH_KEY_NEW_BRANCH, ADD_EDIT_CONTACT_DATA_REQUEST, ADD_EDIT_CONTACT_DATA_RESPONSE } from './ActionTypes';
const initialState = {
    contacts: [
        {
            id: uuidv4(),
            firstName: 'deepa',
            lastName: 'rao'
        },
        {
            id: uuidv4(),
            firstName: 'deepa',
            lastName: 'rao'
        },
        {
            id: uuidv4(),
            firstName: 'deepa',
            lastName: 'rao'
        },
        {
            id: uuidv4(),
            firstName: 'deepa',
            lastName: 'rao'
        },
    ],
    contact: {
        id: '',
        firstName: '',
        lastName: ''
    },
    actionType: 0,
    searchKey: '',
}

const ContactReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_ALL_CONTACTS_DETAILS: {
            return { ...state }
        }
        case DELETE_CONTACT_DATA: {
            // let indexForSpice=action?.payload?.index
            // let contacts1=state?.contacts
            // let contacts1=[...state.contacts]
            // contacts1.splice(indexForSpice,1);
            let contacts1 = state?.contacts
            let newArray = contacts1.filter(x => x?.id !== action?.payload?.data?.id)
            return {
                ...state,
                // contacts:contacts1
                contacts: newArray
            }
        }
        case ADD_EDIT_CONTACT_DATA_REQUEST: {
            let actionType = action?.payload?.actionType
            let contact;
            if (actionType == 2) {
                contact = action?.payload?.data
            }
            else {
                actionType = action?.payload?.actionType
            }
            return {
                ...state,
                actionType: actionType,
                contact: contact
            }
        }
        case SET_SEARCH_KEY_NEW_BRANCH: {
            return {
                ...state,
                searchKey: action.payload
            }
        }
        case ADD_EDIT_CONTACT_DATA_RESPONSE: {
            let actionType = action?.payload?.actionType
            let contact;
            if (actionType == 2) {
                let index = state?.contacts?.findIndex(x => x?.id == action?.payload?.data?.id)
                var contacts2 = [...state?.contacts]
                contact = {
                    id: action?.payload?.data?.id,
                    firstName: action?.payload?.data?.firstName,
                    lastName: action?.payload?.data?.lastName
                }
                contacts2.splice(index, 1, contact)
                actionType = 0
            }
            else {
                var contacts1 = [...state.contacts];
                contacts1.push(action?.payload?.data);
                actionType = 0
            }
            return {
                ...state,
                actionType: actionType,
                contact: contact,
                contacts: contacts2 || contacts1
            }
        }

        default:
            return state;
    }

}

export default ContactReducer
