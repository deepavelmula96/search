import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { ErrorMessage, Field, Formik, Form } from 'formik'
import { v4 as uuidv4 } from 'uuid';
import {addEditContactDataResponse} from '../../store/contact/Actions'


const ContactAction = () => {
    const actionType = useSelector(state => state?.actionType)
    const editData = useSelector(state => state?.contact?.data)
    console.log('actioncomponent11111111111',editData)
    const dispatch=useDispatch()
    const initialValues = {
        firstName: editData?.firstName || '',
        lastName: editData?.lastName || "",
        id:editData?.id ||uuidv4(),
    }
    
    return (
        <div>
        { actionType&&  <Formik
         initialValues={initialValues} 
         onSubmit={(values)=>dispatch(addEditContactDataResponse(actionType,values))}
            enableReinitialize
            // validationSchema={validate}
             >
           { ({setFieldValue})=>
           <Form>
                <div>
                    <label>firstName</label> <br />
                    <Field name='firstName' />
                    <ErrorMessage name='firstName' />
                </div>
                <div>
                    <label>lastName</label> <br />
                    <Field name='lastName' />
                    <ErrorMessage name='lastName' />
                </div>
                <button type='submit'>submit </button>
                <button type='reset'>cancel</button>
            </Form>}
        </Formik>}
    </div>
    )
}
export default ContactAction
