import React from 'react'
import { Button } from 'reactstrap';
import { Modal, ModalBody, ModalHeader } from 'reactstrap';



const NewComponent = (props) => {
    return (
        <div>
               {/* <Button color="danger">Danger!</Button> */}
               <Modal 
            //    isOpen={open} 
               isOpen={true} 
            toggle={() => console.log(false)}
               >
  <ModalHeader>
    Modal title
    <div class="rounded px-3 px-sm-4 py-3 py-sm-5">d</div>
    <div class="rounded px-3 px-sm-4 py-3 py-sm-5">dd</div>

  </ModalHeader>
  <ModalBody>
    Modal body text goes here.
  </ModalBody>
</Modal>
        </div>
    )
}

export default NewComponent

