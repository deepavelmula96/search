import React from 'react'
import { useDispatch } from 'react-redux'
import {addEditContactDataRequest,setSearchKeyNewBranch} from '../../store/contact/Actions'

const ContactFilter = () => {
    const dispatch=useDispatch()
    const onSearchChange = (value) => {
        dispatch(setSearchKeyNewBranch(value))
    }
    return (
        <div>
            <div>
                <input type="text" onChange={(e) => onSearchChange(e.target.value)} />
            </div>
            <button onClick={()=>dispatch(addEditContactDataRequest(1,null))} >Add New Contact</button>

        </div>
    )
}

export default ContactFilter
