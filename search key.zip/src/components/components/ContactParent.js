import React from 'react'
import { useSelector } from 'react-redux'
import { ParentContext } from '../container/ContactContext'
import ContactParentView from './ContactParentView'

const Contact1 = () => {
    const contacts = useSelector(state => state?.contacts)
    console.log('contact1', contacts)
    // const searchKey = useSelector(state => state?.newBranchReducer?.searchKey||'')
    const searchKey = useSelector(state => state?.searchKey||'')

    const newContacts=(contacts && searchKey !== '' )?contacts.filter(x=> (searchKey !== '' ? x?.firstName?.toLowerCase().includes(searchKey.toLowerCase()) : true)):contacts
console.log('newsearch',searchKey)
    return (
        <div>
           { 
           <table>
                <thead>
                    <tr>
                    <th>index</th>
                    <th>id</th>
                    <th>firstName</th>
                    <th>lastName</th>
                    <th>Actions</th>
                    </tr>
                   
                </thead>
                <tbody>
                    {
                        newContacts?.map((x, i) =>
                             
                            {return (
                                <ParentContext.Provider key={x?.id} value={{ data: x ,index:i }}>
                                    <ContactParentView />
                                </ParentContext.Provider>
                            )}
                        
                        // <tr key={i}>
                        //       <td>{x.id}</td>
                        //     <td>{x.firstName}</td>
                        //     <td>{x.lastName}</td>
                          
                           
                        // </tr>
                        
                        //  {
                        //     return (
                        //         <ParentContext.Provider key={x.id} value={{ data: x }}>
                        //             <ContactParentView />
                        //         </ParentContext.Provider>
                        //     )
                        // }
                        )
                    }
                </tbody>
            </table>}
        </div>
    )
}

export default Contact1
