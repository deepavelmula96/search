import React from 'react'
import { useContext } from 'react'
import { useDispatch } from 'react-redux'
import { ParentContext } from '../container/ContactContext'
import {deleteContactData,addEditContactDataRequest} from '../../store/contact/Actions'

const ContactParentView = () => {
    const contacts=useContext(ParentContext)
    let newData=contacts?.data
    let index=contacts?.index
    console.log('ContactParentView',newData)
    const dispatch=useDispatch()
    return (
        <tr>
           <td>{index}</td>
            <td>{newData?.id}</td>
            <td>{newData?.firstName}</td>
            <td>{newData?.lastName}</td>
            <td>
                {/* <button onClick={()=>console.log('view data',contacts)}>view</button> */}
                <button onClick={()=>dispatch(addEditContactDataRequest(2,contacts))}>edit</button>
                <button onClick={()=>dispatch(deleteContactData(contacts))} >delete</button>
            </td>
        </tr>
    )
}

export default ContactParentView
