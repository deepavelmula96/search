
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { getAllContactsDetails } from '../../store/contact/Actions'
import ContactAction from '../components/ContactAction'
import ContactFilter from '../components/ContactFilter'
import Contact1 from '../components/ContactParent'
export class ContactForm extends Component {
    componentDidMount (){
        getAllContactsDetails()
    }
    render() {
        return (
            <div>
           <center>
           <h1>contact Form</h1>
           </center>
           <ContactFilter/>
           <hr />
           <ContactAction/>
           <hr />
           <Contact1/>

            </div>
        )
    }
}

export default connect(null,{getAllContactsDetails}) (ContactForm)
